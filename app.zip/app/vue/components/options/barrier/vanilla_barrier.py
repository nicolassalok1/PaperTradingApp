import streamlit as st

from app.vue.components.options.layout import (
    compute_button,
    option_panel,
    params_expander,
    render_crr_payoff_surface,
)
from app.vue.components.options.pricing import price_barrier_vanilla


def render():
    option_panel("Option barriere vanilla (MC)")
    base = "bar_van_"
    with params_expander():
        col1, col2, col3 = st.columns(3)
        with col1:
            S0 = st.number_input(
                "Sous-jacent (S0)",
                value=100.0,
                min_value=0.01,
                step=1.0,
                key=f"{base}s0",
            )
            K = st.number_input(
                "Strike (K)",
                value=100.0,
                min_value=0.01,
                step=1.0,
                key=f"{base}k",
            )
            barrier = st.number_input(
                "Niveau barriere",
                value=110.0,
                min_value=0.01,
                step=1.0,
                key=f"{base}barrier",
            )
        with col2:
            r = st.number_input(
                "Taux sans risque (r)",
                value=0.02,
                step=0.005,
                format="%.4f",
                key=f"{base}r",
            )
            q = st.number_input(
                "Dividend yield (q)",
                value=0.0,
                step=0.005,
                format="%.4f",
                key=f"{base}q",
            )
            T = st.number_input(
                "Maturite T (annees)",
                value=1.0,
                min_value=0.01,
                step=0.05,
                key=f"{base}t",
            )
        with col3:
            sigma = st.number_input(
                "Volatilite (sigma)",
                value=0.2,
                min_value=0.0001,
                step=0.01,
                format="%.4f",
                key=f"{base}sigma",
            )
            option_type = st.selectbox("Type d'option", ["Call", "Put"], index=0, key=f"{base}type")
            barrier_type = st.selectbox("Direction", ["up", "down"], index=0, key=f"{base}dir")
            knock = st.selectbox("Knock", ["out", "in"], index=0, key=f"{base}knock")
        steps = st.number_input(
            "Nombre d'etapes (n_steps)", value=100, min_value=10, step=10, key=f"{base}steps"
        )
        n_paths = st.number_input(
            "Trajectoires", value=5000, min_value=500, step=500, key=f"{base}paths"
        )

    if compute_button():
        try:
            price = price_barrier_vanilla(
                S0=S0,
                K=K,
                r=r,
                q=q,
                T=T,
                sigma=sigma,
                barrier=barrier,
                barrier_type=barrier_type,
                knock=knock,
                option_type=option_type.lower(),
                steps=int(steps),
                n_paths=int(n_paths),
            )
            st.success(f"Prix barriere {option_type} ({barrier_type}/{knock}) ≈ {price:.4f}")
        except Exception as exc:
            st.error(f"Echec du pricing barriere : {exc}")

    st.markdown("---")
    st.subheader("Surface de payoff (CRR)")
    with st.expander("Previsualisation de la surface de payoff", expanded=False):
        render_crr_payoff_surface(
            S0=S0,
            K=K,
            T=T,
            r=r,
            sigma=sigma,
            option_char="c" if option_type.lower().startswith("c") else "p",
        )
