"""
Reusable Streamlit UI components.
"""
